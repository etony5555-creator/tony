import React, { useState, useEffect } from 'react';
import { Employee, User } from '../types';
import { getEmployees, saveEmployee, deleteEmployee } from '../services/storageService';
import { Users, Plus, Trash2, Calculator, Download } from 'lucide-react';

interface PayrollProps {
  user: User;
}

const Payroll: React.FC<PayrollProps> = ({ user }) => {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [newEmp, setNewEmp] = useState<{ name: string; salary: string }>({ name: '', salary: '' });

  useEffect(() => {
    setEmployees(getEmployees(user.id));
  }, [user]);

  const calculateTax = (gross: number) => {
    // Ethiopian Employment Income Tax Brackets (Proclamation 979/2016)
    if (gross <= 600) return 0;
    if (gross <= 1650) return (gross * 0.10) - 60;
    if (gross <= 3200) return (gross * 0.15) - 142.50;
    if (gross <= 5250) return (gross * 0.20) - 302.50;
    if (gross <= 7800) return (gross * 0.25) - 565;
    if (gross <= 10900) return (gross * 0.30) - 955;
    return (gross * 0.35) - 1500;
  };

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const gross = parseFloat(newEmp.salary);
    if (!newEmp.name || isNaN(gross)) return;

    // Calculations
    // 1. Taxable Income usually implies allowances are handled, here we assume Gross is Taxable for simplicity
    const taxableIncome = gross; 
    const incomeTax = calculateTax(taxableIncome);
    const pension7 = gross * 0.07; // Employee share
    const pension11 = gross * 0.11; // Employer share
    const netPay = gross - incomeTax - pension7;

    const empData: Omit<Employee, 'id'> = {
      userId: user.id,
      fullName: newEmp.name,
      grossSalary: gross,
      taxableIncome,
      incomeTax,
      pension7,
      pension11,
      netPay
    };

    const saved = saveEmployee(empData);
    setEmployees(prev => [...prev, saved]);
    setNewEmp({ name: '', salary: '' });
  };

  const handleDelete = (id: string) => {
    deleteEmployee(id);
    setEmployees(prev => prev.filter(e => e.id !== id));
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Payroll & Pension</h2>
          <p className="text-slate-500 text-sm">Auto-calculate Income Tax (0-35%) and Pension (7%+11%).</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Add Form */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm h-fit">
          <h3 className="font-bold text-lg text-slate-800 mb-4 flex items-center gap-2">
            <Calculator size={20} className="text-indigo-600" />
            New Employee
          </h3>
          <form onSubmit={handleAdd} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Full Name</label>
              <input 
                type="text" 
                required
                className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                value={newEmp.name}
                onChange={e => setNewEmp({ ...newEmp, name: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Gross Salary (ETB)</label>
              <input 
                type="number" 
                required
                className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                value={newEmp.salary}
                onChange={e => setNewEmp({ ...newEmp, salary: e.target.value })}
              />
            </div>
            <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 rounded-lg transition-colors flex items-center justify-center gap-2">
              <Plus size={18} /> Add to Payroll
            </button>
          </form>
        </div>

        {/* Table */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex justify-between items-center">
            <h3 className="font-semibold text-slate-700">Employee Register</h3>
            <span className="text-xs font-mono bg-slate-200 px-2 py-1 rounded">{employees.length} Staff</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left text-slate-600">
              <thead className="text-xs text-slate-500 uppercase bg-slate-50">
                <tr>
                  <th className="px-4 py-3">Name</th>
                  <th className="px-4 py-3 text-right">Gross</th>
                  <th className="px-4 py-3 text-right text-red-500">Tax</th>
                  <th className="px-4 py-3 text-right text-orange-500">Pens(7%)</th>
                  <th className="px-4 py-3 text-right text-emerald-600">Net Pay</th>
                  <th className="px-4 py-3 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {employees.map(emp => (
                  <tr key={emp.id} className="hover:bg-slate-50">
                    <td className="px-4 py-3 font-medium text-slate-900">{emp.fullName}</td>
                    <td className="px-4 py-3 text-right font-mono">{emp.grossSalary.toFixed(2)}</td>
                    <td className="px-4 py-3 text-right font-mono text-red-600">{emp.incomeTax.toFixed(2)}</td>
                    <td className="px-4 py-3 text-right font-mono text-orange-600">{emp.pension7.toFixed(2)}</td>
                    <td className="px-4 py-3 text-right font-mono font-bold text-emerald-700">{emp.netPay.toFixed(2)}</td>
                    <td className="px-4 py-3 text-center">
                      <button onClick={() => handleDelete(emp.id)} className="text-slate-400 hover:text-red-500">
                        <Trash2 size={16} />
                      </button>
                    </td>
                  </tr>
                ))}
                {employees.length === 0 && (
                  <tr><td colSpan={6} className="text-center py-8 text-slate-400">No employees added yet.</td></tr>
                )}
              </tbody>
            </table>
          </div>
          {employees.length > 0 && (
            <div className="p-4 bg-slate-50 border-t border-slate-200 grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
               <div>
                 <p className="text-slate-500 uppercase">Total Tax</p>
                 <p className="font-bold text-slate-800 text-lg">ETB {employees.reduce((a,b) => a + b.incomeTax, 0).toFixed(2)}</p>
               </div>
               <div>
                 <p className="text-slate-500 uppercase">Total Pension (18%)</p>
                 <p className="font-bold text-slate-800 text-lg">ETB {employees.reduce((a,b) => a + b.pension7 + b.pension11, 0).toFixed(2)}</p>
               </div>
               <div>
                 <p className="text-slate-500 uppercase">Net Payable</p>
                 <p className="font-bold text-emerald-600 text-lg">ETB {employees.reduce((a,b) => a + b.netPay, 0).toFixed(2)}</p>
               </div>
               <div className="flex items-center justify-end">
                 <button className="flex items-center gap-2 text-indigo-600 hover:text-indigo-800 font-bold">
                    <Download size={16} /> Export Report
                 </button>
               </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Payroll;

import React, { useState } from 'react';
import { loginUser, registerUser } from '../services/storageService';
import { User } from '../types';
import { ShieldCheck } from 'lucide-react';

interface AuthProps {
  onLogin: (user: User) => void;
}

const Auth: React.FC<AuthProps> = ({ onLogin }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [businessName, setBusinessName] = useState('');
  const [tin, setTin] = useState('');
  const [businessType, setBusinessType] = useState('Sole Proprietorship');
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (isLogin) {
      const user = loginUser(email);
      if (user) {
        onLogin(user);
      } else {
        setError("User not found. Please check email or register.");
      }
    } else {
      if (!businessName || !tin) {
        setError("All fields are required.");
        return;
      }
      const user = registerUser(email, businessName, tin, businessType);
      if (user) {
        onLogin(user);
      } else {
        setError("User already exists with this email.");
      }
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
      <div className="mb-8 flex flex-col items-center">
        <div className="w-16 h-16 bg-emerald-600 rounded-2xl flex items-center justify-center text-white mb-4 shadow-lg shadow-emerald-200">
          <ShieldCheck size={40} />
        </div>
        <h1 className="text-4xl font-extrabold text-slate-900 tracking-tight">Tony Tax Manager</h1>
        <p className="text-slate-500 mt-2">Your Ethiopian Business Accountant</p>
      </div>

      <div className="bg-white p-8 rounded-2xl shadow-xl w-full max-w-md border border-slate-100">
        <h2 className="text-2xl font-bold text-slate-800 mb-6 text-center">
          {isLogin ? 'Welcome Back' : 'Create Client Profile'}
        </h2>
        
        {error && (
          <div className="mb-4 p-3 bg-red-50 text-red-600 text-sm rounded-lg border border-red-100">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Email Address</label>
            <input 
              type="email" 
              required 
              className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
              placeholder="you@company.com"
              value={email}
              onChange={e => setEmail(e.target.value)}
            />
          </div>

          {!isLogin && (
            <>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Business Name</label>
                <input 
                  type="text" 
                  required 
                  className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                  placeholder="Abebe Trading"
                  value={businessName}
                  onChange={e => setBusinessName(e.target.value)}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">TIN Number</label>
                <input 
                  type="text" 
                  required 
                  className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                  placeholder="0012345678"
                  value={tin}
                  onChange={e => setTin(e.target.value)}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Business Type</label>
                <select 
                  className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all bg-white"
                  value={businessType}
                  onChange={e => setBusinessType(e.target.value)}
                >
                  <option value="Sole Proprietorship">Sole Proprietorship</option>
                  <option value="PLC">Private Limited Company (PLC)</option>
                  <option value="Share Company">Share Company</option>
                  <option value="Micro Enterprise">Micro Enterprise</option>
                </select>
              </div>
            </>
          )}

          <button 
            type="submit" 
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 rounded-lg transition-all shadow-md hover:shadow-lg mt-2"
          >
            {isLogin ? 'Sign In' : 'Create Profile'}
          </button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-sm text-slate-600">
            {isLogin ? "New business?" : "Already registered?"}
            <button 
              onClick={() => { setIsLogin(!isLogin); setError(null); }}
              className="ml-1 font-semibold text-emerald-600 hover:text-emerald-800 hover:underline"
            >
              {isLogin ? 'Register Profile' : 'Log In'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Auth;
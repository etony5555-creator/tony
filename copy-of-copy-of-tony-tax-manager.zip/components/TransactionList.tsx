import React, { useState, useEffect } from 'react';
import { Transaction, TransactionType } from '../types';
import { Trash2, Search, Filter, Plus, Edit2, ReceiptText, Clock, Calculator, AlertTriangle } from 'lucide-react';

interface TransactionListProps {
  transactions: Transaction[];
  onDelete: (id: string) => void;
  onAdd: (t: Omit<Transaction, 'id'>) => void;
  onUpdate: (t: Transaction) => void;
  userId: string;
}

const ToggleSwitch = ({ checked, onChange, label, colorClass = 'bg-emerald-500' }: { checked: boolean; onChange: (val: boolean) => void; label?: string; colorClass?: string }) => (
  <div className="flex items-center gap-3 cursor-pointer" onClick={(e) => { e.stopPropagation(); onChange(!checked); }}>
    <div
      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 ${
        checked ? colorClass : 'bg-slate-300'
      }`}
    >
      <span
        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
          checked ? 'translate-x-6' : 'translate-x-1'
        }`}
      />
    </div>
    {label && <span className="text-sm font-medium text-slate-700">{label}</span>}
  </div>
);

const TransactionList: React.FC<TransactionListProps> = ({ transactions, onDelete, onAdd, onUpdate, userId }) => {
  const [search, setSearch] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  
  const [newTrans, setNewTrans] = useState<Partial<Transaction>>({
    type: TransactionType.EXPENSE,
    date: new Date().toISOString().split('T')[0],
    category: 'General',
    isDeductible: false,
    isVATApplicable: false,
    vatAmount: 0,
    isWithholdingApplicable: false,
    withholdingTax: 0
  });

  // Auto-checks
  useEffect(() => {
    // VAT Calc
    if (newTrans.isVATApplicable && newTrans.amount && (!newTrans.vatAmount || newTrans.vatAmount === 0)) {
        const calculated = (newTrans.amount * 0.15) / 1.15;
        setNewTrans(prev => ({ ...prev, vatAmount: parseFloat(calculated.toFixed(2)) }));
    }
    // Withholding Calc (If Amount >= 3000 ETB and Expense)
    if (newTrans.type === TransactionType.EXPENSE && newTrans.amount && newTrans.amount >= 3000) {
      if (newTrans.isWithholdingApplicable === undefined) {
         setNewTrans(prev => ({...prev, isWithholdingApplicable: true}));
      }
    }
  }, [newTrans.isVATApplicable, newTrans.amount, newTrans.type]);

  // Update withholding amount if applicable is toggled
  useEffect(() => {
    if (newTrans.isWithholdingApplicable && newTrans.amount) {
       // 2% of Gross amount
       const wht = newTrans.amount * 0.02;
       setNewTrans(prev => ({...prev, withholdingTax: parseFloat(wht.toFixed(2))}));
    } else {
       setNewTrans(prev => ({...prev, withholdingTax: 0}));
    }
  }, [newTrans.isWithholdingApplicable, newTrans.amount]);


  const filtered = transactions.filter(t => 
    t.merchant.toLowerCase().includes(search.toLowerCase()) || 
    t.category.toLowerCase().includes(search.toLowerCase())
  );

  const handleEditClick = (t: Transaction) => {
    setNewTrans(t);
    setEditingId(t.id);
    setShowAddModal(true);
  };

  const handleCloseModal = () => {
    setShowAddModal(false);
    setEditingId(null);
    setNewTrans({
      type: TransactionType.EXPENSE,
      date: new Date().toISOString().split('T')[0],
      category: 'General',
      isDeductible: false,
      isVATApplicable: false,
      vatAmount: 0,
      isWithholdingApplicable: false,
      withholdingTax: 0
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTrans.amount || !newTrans.merchant || !newTrans.date) return;

    const transactionData = {
      userId,
      date: newTrans.date!,
      merchant: newTrans.merchant!,
      amount: parseFloat(newTrans.amount.toString()),
      type: newTrans.type || TransactionType.EXPENSE,
      category: newTrans.category || 'General',
      isDeductible: newTrans.isDeductible || false,
      isVATApplicable: newTrans.isVATApplicable || false,
      vatAmount: newTrans.isVATApplicable ? parseFloat((newTrans.vatAmount || 0).toString()) : 0,
      isWithholdingApplicable: newTrans.isWithholdingApplicable || false,
      withholdingTax: newTrans.isWithholdingApplicable ? parseFloat((newTrans.withholdingTax || 0).toString()) : 0,
      description: newTrans.description || '',
    };

    if (editingId) {
      onUpdate({ ...transactionData, id: editingId } as Transaction);
    } else {
      onAdd(transactionData);
    }
    
    handleCloseModal();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h2 className="text-2xl font-bold text-slate-800">Financial Ledger</h2>
        <button 
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg transition-colors text-sm font-medium shadow-sm"
        >
          <Plus size={18} />
          {editingId ? 'Edit Entry' : 'New Entry'}
        </button>
      </div>

      {/* Search & Filter Bar */}
      <div className="flex items-center gap-4 bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
          <input 
            type="text" 
            placeholder="Search merchant, category, or ID..." 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
          />
        </div>
      </div>

      {/* List */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left text-slate-600">
            <thead className="text-xs text-slate-500 uppercase bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="px-6 py-4">Date</th>
                <th className="px-6 py-4">Merchant / Source</th>
                <th className="px-6 py-4">Category</th>
                <th className="px-6 py-4 text-center">Tax Flags</th>
                <th className="px-6 py-4 text-right">Amount (ETB)</th>
                <th className="px-6 py-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((t) => (
                <tr key={t.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap font-mono text-xs">{t.date}</td>
                  <td className="px-6 py-4 font-medium text-slate-900">
                    {t.merchant}
                    {t.isWithholdingApplicable && (
                      <span className="ml-2 text-[10px] bg-orange-100 text-orange-700 px-1 py-0.5 rounded border border-orange-200">WHT 2%</span>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <span className="px-2.5 py-1 bg-slate-100 text-slate-700 rounded-full text-xs font-medium border border-slate-200">
                      {t.category}
                    </span>
                  </td>
                   <td className="px-6 py-4 text-center space-y-1">
                    {t.isVATApplicable && (
                        <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold bg-blue-100 text-blue-800 mx-1" title="VAT">
                          VAT
                        </span>
                    )}
                    {t.isDeductible && (
                        <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 mx-1" title="Deductible">
                          DED
                        </span>
                    )}
                  </td>
                  <td className={`px-6 py-4 text-right font-bold font-mono ${t.type === TransactionType.INCOME ? 'text-emerald-600' : 'text-slate-800'}`}>
                    {t.type === TransactionType.INCOME ? '+' : '-'} {t.amount.toFixed(2)}
                  </td>
                  <td className="px-6 py-4 text-center">
                    <div className="flex items-center justify-center gap-2">
                      <button 
                        onClick={() => handleEditClick(t)}
                        className="text-slate-400 hover:text-indigo-600 transition-colors p-1"
                      >
                        <Edit2 size={18} />
                      </button>
                      <button 
                        onClick={() => onDelete(t.id)}
                        className="text-slate-400 hover:text-red-500 transition-colors p-1"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-slate-400">
                    No records found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Manual Add/Edit Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full animate-in fade-in zoom-in-95 duration-200 my-8">
            <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex justify-between items-center sticky top-0 bg-slate-50 rounded-t-xl z-10">
              <h3 className="font-bold text-lg text-slate-800 flex items-center gap-2">
                <ReceiptText size={20} className="text-indigo-600"/>
                {editingId ? 'Edit Ledger Entry' : 'New Ledger Entry'}
              </h3>
              <button onClick={handleCloseModal} className="text-slate-400 hover:text-slate-600 transition-colors">✕</button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-5">
              {/* Basic Info */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Transaction Type</label>
                  <select 
                    className="w-full p-2.5 border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-indigo-500"
                    value={newTrans.type} 
                    onChange={e => setNewTrans({...newTrans, type: e.target.value as TransactionType})}
                  >
                    <option value={TransactionType.EXPENSE}>Expense</option>
                    <option value={TransactionType.INCOME}>Income</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Date</label>
                  <input 
                    type="date" 
                    required
                    className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                    value={newTrans.date}
                    onChange={e => setNewTrans({...newTrans, date: e.target.value})}
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Merchant / Source</label>
                <input 
                  type="text" 
                  required
                  className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  value={newTrans.merchant || ''}
                  onChange={e => setNewTrans({...newTrans, merchant: e.target.value})}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Total Amount (Gross)</label>
                  <input 
                    type="number" 
                    required
                    step="0.01"
                    className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 font-mono"
                    value={newTrans.amount || ''}
                    onChange={e => setNewTrans({...newTrans, amount: parseFloat(e.target.value)})}
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Category</label>
                  <input 
                    type="text" 
                    list="categories"
                    className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                    value={newTrans.category || ''}
                    onChange={e => setNewTrans({...newTrans, category: e.target.value})}
                  />
                  <datalist id="categories">
                    <option value="Office Supplies" />
                    <option value="Meals & Entertainment" />
                    <option value="Travel & Transport" />
                    <option value="Rent" />
                    <option value="Telecom" />
                    <option value="Raw Materials" />
                  </datalist>
                </div>
              </div>

              {/* Advanced Tax Compliance Section */}
              <div className="space-y-3 pt-2 border-t border-slate-100">
                 <p className="text-xs font-bold text-slate-400 uppercase">Compliance Checks</p>
                 
                 {/* Deductible */}
                 <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 flex justify-between items-center">
                      <div>
                          <label className="block text-sm font-bold text-slate-700">Tax Deductible</label>
                      </div>
                      <ToggleSwitch 
                        checked={!!newTrans.isDeductible}
                        onChange={val => setNewTrans({...newTrans, isDeductible: val})}
                      />
                 </div>

                 {/* VAT */}
                 <div className={`p-3 rounded-lg border transition-all ${newTrans.isVATApplicable ? 'bg-blue-50/50 border-blue-200' : 'bg-slate-50 border-slate-200'}`}>
                   <div className="flex justify-between items-center mb-2">
                      <label className="block text-sm font-bold text-slate-700">VAT Applicable (15%)</label>
                      <ToggleSwitch 
                        colorClass="bg-blue-600"
                        checked={!!newTrans.isVATApplicable}
                        onChange={val => setNewTrans({...newTrans, isVATApplicable: val})}
                      />
                   </div>
                   {newTrans.isVATApplicable && (
                      <div className="flex items-center gap-2 mt-2">
                        <span className="text-xs text-slate-500">VAT Amt:</span>
                        <input type="number" className="w-24 p-1 border rounded text-sm" value={newTrans.vatAmount || ''} onChange={e => setNewTrans({...newTrans, vatAmount: parseFloat(e.target.value)})} />
                      </div>
                   )}
                 </div>

                 {/* Withholding Tax (Only for Expenses) */}
                 {newTrans.type === TransactionType.EXPENSE && (
                   <div className={`p-3 rounded-lg border transition-all ${newTrans.isWithholdingApplicable ? 'bg-orange-50 border-orange-200' : 'bg-slate-50 border-slate-200'}`}>
                      <div className="flex justify-between items-center mb-2">
                          <div>
                            <label className="block text-sm font-bold text-slate-700 flex items-center gap-2">
                              Withholding Tax (2%)
                              {(newTrans.amount || 0) >= 3000 && <AlertTriangle size={14} className="text-orange-500" />}
                            </label>
                            <span className="text-[10px] text-slate-400">Required for payments {'>='} 3,000 ETB</span>
                          </div>
                          <ToggleSwitch 
                            colorClass="bg-orange-500"
                            checked={!!newTrans.isWithholdingApplicable}
                            onChange={val => setNewTrans({...newTrans, isWithholdingApplicable: val})}
                          />
                      </div>
                       {newTrans.isWithholdingApplicable && (
                        <div className="mt-1 text-xs text-orange-700 font-medium flex justify-between">
                           <span>Retain: ETB {newTrans.withholdingTax?.toFixed(2)}</span>
                           <span>Pay Vendor: ETB {((newTrans.amount || 0) - (newTrans.withholdingTax || 0)).toFixed(2)}</span>
                        </div>
                      )}
                   </div>
                 )}
              </div>

              <button 
                type="submit" 
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3.5 rounded-lg transition-colors shadow-lg shadow-indigo-200"
              >
                {editingId ? 'Update Entry' : 'Save Entry'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default TransactionList;

import React, { useState, useEffect } from 'react';
import { Invoice, User } from '../types';
import { getInvoices, saveInvoice } from '../services/storageService';
import { FileText, Plus, Printer, Send } from 'lucide-react';

interface InvoicesProps {
  user: User;
}

const Invoices: React.FC<InvoicesProps> = ({ user }) => {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [newInv, setNewInv] = useState<Partial<Invoice>>({
    clientName: '',
    items: [{ description: '', quantity: 1, unitPrice: 0, total: 0 }]
  });

  useEffect(() => {
    setInvoices(getInvoices(user.id));
  }, [user]);

  const handleAddItem = () => {
    const items = newInv.items || [];
    setNewInv({ ...newInv, items: [...items, { description: '', quantity: 1, unitPrice: 0, total: 0 }] });
  };

  const updateItem = (idx: number, field: string, val: string | number) => {
    const items = [...(newInv.items || [])];
    // @ts-ignore
    items[idx][field] = val;
    items[idx].total = items[idx].quantity * items[idx].unitPrice;
    setNewInv({ ...newInv, items });
  };

  const calculateTotals = () => {
    const subtotal = newInv.items?.reduce((acc, item) => acc + item.total, 0) || 0;
    const taxRate = user.taxMode === 'VAT' ? 0.15 : (user.totRate ? user.totRate / 100 : 0);
    const taxAmount = subtotal * taxRate;
    return { subtotal, taxAmount, grandTotal: subtotal + taxAmount };
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const { subtotal, taxAmount, grandTotal } = calculateTotals();
    const invData: Omit<Invoice, 'id'> = {
      userId: user.id,
      clientName: newInv.clientName || 'Client',
      clientTIN: newInv.clientTIN || '',
      date: new Date().toISOString().split('T')[0],
      dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      items: newInv.items || [],
      subtotal,
      taxAmount,
      grandTotal,
      status: 'DRAFT',
      invoiceNumber: `INV-${Math.floor(Math.random() * 10000)}`
    };
    const saved = saveInvoice(invData);
    setInvoices(prev => [saved, ...prev]);
    setShowForm(false);
    setNewInv({ clientName: '', items: [{ description: '', quantity: 1, unitPrice: 0, total: 0 }] });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-slate-800">Invoices</h2>
        <button onClick={() => setShowForm(!showForm)} className="bg-indigo-600 text-white px-4 py-2 rounded-lg flex items-center gap-2">
          <Plus size={18} /> New Invoice
        </button>
      </div>

      {showForm && (
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-lg">
          <h3 className="font-bold text-lg mb-4">Draft New Invoice ({user.taxMode})</h3>
          <form onSubmit={handleSave} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <input 
                className="p-2 border rounded" 
                placeholder="Client Name" 
                value={newInv.clientName}
                onChange={e => setNewInv({...newInv, clientName: e.target.value})}
                required 
              />
              <input 
                className="p-2 border rounded" 
                placeholder="Client TIN (Optional)" 
                value={newInv.clientTIN}
                onChange={e => setNewInv({...newInv, clientTIN: e.target.value})}
              />
            </div>
            
            <div className="space-y-2">
              <div className="flex font-bold text-xs uppercase text-slate-500 pb-1">
                <div className="flex-1">Item</div>
                <div className="w-20">Qty</div>
                <div className="w-32">Price</div>
                <div className="w-32 text-right">Total</div>
              </div>
              {newInv.items?.map((item, idx) => (
                <div key={idx} className="flex gap-2">
                  <input className="flex-1 p-2 border rounded" placeholder="Description" value={item.description} onChange={e => updateItem(idx, 'description', e.target.value)} />
                  <input className="w-20 p-2 border rounded" type="number" value={item.quantity} onChange={e => updateItem(idx, 'quantity', parseFloat(e.target.value))} />
                  <input className="w-32 p-2 border rounded" type="number" value={item.unitPrice} onChange={e => updateItem(idx, 'unitPrice', parseFloat(e.target.value))} />
                  <div className="w-32 p-2 bg-slate-50 rounded text-right">{item.total.toFixed(2)}</div>
                </div>
              ))}
              <button type="button" onClick={handleAddItem} className="text-sm text-indigo-600 hover:underline">+ Add Item</button>
            </div>

            <div className="flex justify-end pt-4 border-t">
               <div className="w-64 space-y-2">
                 <div className="flex justify-between text-sm"><span>Subtotal</span> <span>{calculateTotals().subtotal.toFixed(2)}</span></div>
                 <div className="flex justify-between text-sm"><span>{user.taxMode}</span> <span>{calculateTotals().taxAmount.toFixed(2)}</span></div>
                 <div className="flex justify-between font-bold text-lg"><span>Total</span> <span>{calculateTotals().grandTotal.toFixed(2)}</span></div>
                 <button type="submit" className="w-full bg-emerald-600 text-white py-2 rounded mt-2">Save Invoice</button>
               </div>
            </div>
          </form>
        </div>
      )}

      <div className="grid gap-4">
        {invoices.map(inv => (
          <div key={inv.id} className="bg-white p-4 rounded-xl border border-slate-200 flex justify-between items-center hover:shadow-md transition-shadow">
            <div className="flex items-center gap-4">
               <div className="p-3 bg-indigo-50 text-indigo-600 rounded-lg"><FileText size={24} /></div>
               <div>
                 <p className="font-bold text-slate-800">{inv.clientName}</p>
                 <p className="text-xs text-slate-500">{inv.invoiceNumber} • {inv.date}</p>
               </div>
            </div>
            <div className="flex items-center gap-6">
               <div className="text-right">
                 <p className="font-bold text-slate-800">ETB {inv.grandTotal.toFixed(2)}</p>
                 <span className="text-[10px] bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full font-bold">{inv.status}</span>
               </div>
               <div className="flex gap-2">
                 <button className="p-2 text-slate-400 hover:text-indigo-600"><Printer size={20}/></button>
                 <button className="p-2 text-slate-400 hover:text-emerald-600"><Send size={20}/></button>
               </div>
            </div>
          </div>
        ))}
        {invoices.length === 0 && !showForm && <p className="text-center text-slate-400 py-8">No invoices yet.</p>}
      </div>
    </div>
  );
};

export default Invoices;

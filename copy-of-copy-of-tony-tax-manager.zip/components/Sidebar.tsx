import React from 'react';
import { Link, useLocation } from 'react-router-dom'; 
import { LayoutDashboard, Receipt, PieChart, ScanLine, Settings, X, Building2, MessageSquare, Users, FileText } from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose }) => {
  const location = useLocation();
  
  const navItems = [
    { path: '/', label: 'Dashboard', icon: LayoutDashboard },
    { path: '/chat', label: 'Ask Tony (AI)', icon: MessageSquare },
    { path: '/transactions', label: 'Transactions', icon: Receipt },
    { path: '/scan', label: 'Smart Scan', icon: ScanLine },
    { path: '/invoices', label: 'Invoicing', icon: FileText },
    { path: '/payroll', label: 'Payroll & Pension', icon: Users },
    { path: '/reports', label: 'Tax Reports', icon: PieChart },
    { path: '/profile', label: 'Business Profile', icon: Building2 },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <>
      {/* Overlay for mobile */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-30 lg:hidden"
          onClick={onClose}
        />
      )}
      
      <aside className={`
        fixed top-0 left-0 z-40 h-full w-64 bg-white border-r border-slate-200 transform transition-transform duration-300 ease-in-out
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
        lg:translate-x-0 lg:static lg:h-[calc(100vh-4rem)]
      `}>
        <div className="h-full flex flex-col p-4">
          <div className="flex items-center justify-between mb-8 lg:hidden">
            <span className="font-bold text-lg text-indigo-600">TaxMind Menu</span>
            <button onClick={onClose} className="p-2 text-slate-500">
              <X size={24} />
            </button>
          </div>

          <nav className="space-y-1 flex-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = isActive(item.path);
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => onClose()} 
                  className={`
                    flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors
                    ${active 
                      ? 'bg-indigo-50 text-indigo-700' 
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'}
                  `}
                >
                  <Icon size={20} />
                  {item.label}
                </Link>
              );
            })}
          </nav>

          <div className="mt-auto pt-4 border-t border-slate-200">
            <Link to="/profile" className="flex items-center gap-3 px-4 py-3 w-full text-slate-500 hover:text-slate-900 text-sm font-medium transition-colors">
              <Settings size={20} />
              Settings
            </Link>
          </div>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;

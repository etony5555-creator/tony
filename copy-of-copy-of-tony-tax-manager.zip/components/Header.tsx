import React from 'react';
import { Link } from 'react-router-dom';
import { Menu, LogOut, User as UserIcon } from 'lucide-react';
import { User } from '../types';

interface HeaderProps {
  user: User | null;
  onLogout: () => void;
  toggleSidebar: () => void;
}

const Header: React.FC<HeaderProps> = ({ user, onLogout, toggleSidebar }) => {
  return (
    <header className="bg-white border-b border-slate-200 h-16 flex items-center justify-between px-4 lg:px-8 sticky top-0 z-20">
      <div className="flex items-center gap-4">
        <button onClick={toggleSidebar} className="lg:hidden p-2 text-slate-600 hover:bg-slate-100 rounded-md">
          <Menu size={24} />
        </button>
        <Link to="/" className="flex items-center gap-2">
          <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center text-white font-bold">
            T
          </div>
          <span className="text-xl font-bold text-slate-800 hidden sm:block">Tony Tax Manager</span>
        </Link>
      </div>

      {user && (
        <div className="flex items-center gap-4">
          <Link to="/profile" className="flex items-center gap-3 hover:bg-slate-50 p-1.5 rounded-lg transition-colors group">
            <div className="hidden md:flex flex-col items-end">
              <span className="text-sm font-medium text-slate-900 group-hover:text-indigo-700">{user.businessName}</span>
              <span className="text-xs text-slate-500">TIN: {user.tin}</span>
            </div>
            <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center text-slate-600 border border-slate-200 group-hover:border-indigo-200 group-hover:bg-indigo-50 group-hover:text-indigo-600">
              <UserIcon size={20} />
            </div>
          </Link>
          <button 
            onClick={onLogout}
            className="p-2 text-slate-500 hover:text-red-600 transition-colors border-l border-slate-200 pl-4"
            title="Logout"
          >
            <LogOut size={20} />
          </button>
        </div>
      )}
    </header>
  );
};

export default Header;
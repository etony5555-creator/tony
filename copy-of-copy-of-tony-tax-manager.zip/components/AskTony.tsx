import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, Send, Bot, User as UserIcon, Loader2, Sparkles } from 'lucide-react';
import { askTony } from '../services/geminiService';
import ReactMarkdown from 'react-markdown';
import { User, Transaction } from '../types';

interface AskTonyProps {
  user: User;
  transactions: Transaction[];
}

interface Message {
  role: 'user' | 'model';
  text: string;
  time: string;
}

const AskTony: React.FC<AskTonyProps> = ({ user, transactions }) => {
  const [query, setQuery] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: `Hello ${user.businessName}! I'm Tony, your AI financial advisor. Ask me about your expenses, tax rules, or profit analysis.`, time: new Date().toLocaleTimeString() }
  ]);
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(scrollToBottom, [messages]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    const userMsg: Message = { role: 'user', text: query, time: new Date().toLocaleTimeString() };
    setMessages(prev => [...prev, userMsg]);
    setQuery('');
    setLoading(true);

    // Prepare context
    const summary = `
      Business: ${user.businessName} (${user.businessType})
      Tax Mode: ${user.taxMode}
      Total Transactions: ${transactions.length}
      Last 5 Transactions: ${JSON.stringify(transactions.slice(0, 5))}
    `;

    try {
      const responseText = await askTony(userMsg.text, summary);
      const botMsg: Message = { role: 'model', text: responseText, time: new Date().toLocaleTimeString() };
      setMessages(prev => [...prev, botMsg]);
    } catch (err) {
      setMessages(prev => [...prev, { role: 'model', text: "I encountered an error analyzing that.", time: new Date().toLocaleTimeString() }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 h-[calc(100vh-8rem)] flex flex-col">
      <div className="p-4 border-b border-slate-200 flex items-center gap-3 bg-indigo-50/50 rounded-t-xl">
        <div className="w-10 h-10 bg-indigo-600 rounded-full flex items-center justify-center text-white shadow-md shadow-indigo-200">
          <Sparkles size={20} />
        </div>
        <div>
          <h2 className="font-bold text-slate-800">Ask Tony</h2>
          <p className="text-xs text-slate-500">Powered by Gemini 3 Pro (Thinking Mode)</p>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50/30">
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            {msg.role === 'model' && (
               <div className="w-8 h-8 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center shrink-0">
                 <Bot size={18} />
               </div>
            )}
            <div className={`max-w-[80%] rounded-2xl p-4 ${msg.role === 'user' ? 'bg-indigo-600 text-white rounded-tr-none' : 'bg-white border border-slate-200 text-slate-800 rounded-tl-none shadow-sm'}`}>
              <ReactMarkdown className={`prose text-sm ${msg.role === 'user' ? 'text-white prose-headings:text-white prose-p:text-white' : 'text-slate-800'}`}>
                {msg.text}
              </ReactMarkdown>
              <p className={`text-[10px] mt-2 text-right opacity-70`}>{msg.time}</p>
            </div>
            {msg.role === 'user' && (
               <div className="w-8 h-8 bg-slate-200 text-slate-600 rounded-full flex items-center justify-center shrink-0">
                 <UserIcon size={18} />
               </div>
            )}
          </div>
        ))}
        {loading && (
          <div className="flex gap-3">
            <div className="w-8 h-8 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center">
               <Bot size={18} />
            </div>
            <div className="bg-white border border-slate-200 px-4 py-3 rounded-2xl rounded-tl-none flex items-center gap-2 text-slate-500 text-sm shadow-sm">
              <Loader2 className="animate-spin" size={16} />
              Tony is thinking...
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <form onSubmit={handleSend} className="p-4 border-t border-slate-200 bg-white rounded-b-xl">
        <div className="relative">
          <input
            type="text"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Ask about withholding tax, profit margins, or audit risks..."
            className="w-full pl-4 pr-12 py-3.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
            disabled={loading}
          />
          <button 
            type="submit"
            disabled={loading || !query.trim()} 
            className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50 disabled:hover:bg-indigo-600 transition-colors"
          >
            <Send size={18} />
          </button>
        </div>
      </form>
    </div>
  );
};

export default AskTony;

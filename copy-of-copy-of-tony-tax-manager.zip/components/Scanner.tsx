import React, { useState, useRef } from 'react';
import { analyzeReceiptImage } from '../services/geminiService';
import { Transaction, TransactionType } from '../types';
import { Camera, Loader2, CheckCircle, XCircle } from 'lucide-react';

interface ScannerProps {
  onScanComplete: (transaction: Omit<Transaction, 'id'>) => void;
  userId: string;
}

const Scanner: React.FC<ScannerProps> = ({ onScanComplete, userId }) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [result, setResult] = useState<Omit<Transaction, 'id'> | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setError(null);
    setResult(null);

    // Create preview
    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = reader.result as string;
      setPreview(base64);
      processImage(base64);
    };
    reader.readAsDataURL(file);
  };

  const processImage = async (base64: string) => {
    setIsProcessing(true);
    try {
      const data = await analyzeReceiptImage(base64);
      
      // Calculate VAT if applicable (default 15% inclusive assumption)
      const calculatedVat = data.isVATApplicable && data.amount 
        ? parseFloat(((data.amount * 0.15) / 1.15).toFixed(2))
        : 0;

      const transaction: Omit<Transaction, 'id'> = {
        userId,
        date: data.date || new Date().toISOString().split('T')[0],
        merchant: data.merchant || "Unknown Merchant",
        amount: data.amount || 0,
        category: data.category || "Uncategorized",
        description: data.description || "Receipt Scan",
        type: TransactionType.EXPENSE,
        isDeductible: data.isDeductible,
        isVATApplicable: data.isVATApplicable,
        vatAmount: calculatedVat,
        receiptUrl: base64 // In a real app, upload to storage and save URL
      };
      setResult(transaction);
    } catch (err) {
      setError("Failed to analyze receipt. Please try a clearer image or enter manually.");
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSave = () => {
    if (result) {
      onScanComplete(result);
      setPreview(null);
      setResult(null);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-2xl font-bold text-slate-800">AI Auditor Scan</h2>
        <p className="text-slate-500">Upload a receipt. Tony will extract data and audit for VAT & Deductibility.</p>
      </div>

      <div className={`
        border-2 border-dashed rounded-2xl p-8 flex flex-col items-center justify-center transition-colors min-h-[300px]
        ${preview ? 'border-indigo-200 bg-slate-50' : 'border-slate-300 hover:border-indigo-400 hover:bg-slate-50 cursor-pointer'}
      `}
      onClick={() => !preview && fileInputRef.current?.click()}
      >
        {preview ? (
          <div className="relative w-full max-w-md">
            <img src={preview} alt="Receipt" className="rounded-lg shadow-lg w-full object-contain max-h-[400px]" />
            {isProcessing && (
              <div className="absolute inset-0 bg-black/50 rounded-lg flex items-center justify-center text-white">
                <div className="flex flex-col items-center gap-3">
                  <Loader2 className="animate-spin" size={40} />
                  <span className="font-medium">Auditing with Gemini AI...</span>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="flex flex-col items-center gap-4 text-slate-400">
            <div className="w-16 h-16 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center">
              <Camera size={32} />
            </div>
            <div className="text-center">
              <p className="text-lg font-semibold text-slate-700">Click to Upload Evidence</p>
              <p className="text-sm">or select a file</p>
            </div>
          </div>
        )}
        <input 
          type="file" 
          ref={fileInputRef} 
          onChange={handleFileSelect} 
          accept="image/*" 
          className="hidden" 
        />
      </div>

      {error && (
        <div className="bg-red-50 text-red-600 p-4 rounded-xl flex items-center gap-3 border border-red-100">
          <XCircle size={20} />
          {error}
        </div>
      )}

      {result && !isProcessing && (
        <div className="bg-white p-6 rounded-xl shadow-lg border border-indigo-100 ring-1 ring-indigo-500/20 animate-in slide-in-from-bottom-4">
          <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-4">
            <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              <CheckCircle className="text-emerald-500" size={20} />
              Audit Complete
            </h3>
            <span className="text-xs font-medium bg-indigo-100 text-indigo-700 px-2 py-1 rounded">
              Confidence: High
            </span>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
            <div>
              <label className="text-xs text-slate-400 uppercase font-bold">Merchant</label>
              <p className="text-slate-900 font-medium">{result.merchant}</p>
            </div>
            <div>
              <label className="text-xs text-slate-400 uppercase font-bold">Date</label>
              <p className="text-slate-900 font-medium">{result.date}</p>
            </div>
            <div>
              <label className="text-xs text-slate-400 uppercase font-bold">Total Amount</label>
              <p className="text-indigo-600 font-bold text-lg">ETB {result.amount.toFixed(2)}</p>
            </div>
            <div>
              <label className="text-xs text-slate-400 uppercase font-bold">Category</label>
              <p className="text-slate-900 font-medium">{result.category}</p>
            </div>
            
            <div className="bg-slate-50 p-3 rounded-lg border border-slate-100 sm:col-span-2 grid grid-cols-2 gap-4">
                <div>
                    <label className="text-xs text-slate-500 uppercase font-bold">Tax Deductible</label>
                    <div className="mt-1">
                        {result.isDeductible ? (
                        <span className="text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded text-sm font-bold">Yes</span>
                        ) : (
                        <span className="text-slate-600 bg-slate-100 px-2 py-0.5 rounded text-sm font-bold">No</span>
                        )}
                    </div>
                </div>
                <div>
                    <label className="text-xs text-slate-500 uppercase font-bold">VAT Applicable (15%)</label>
                    <div className="mt-1">
                        {result.isVATApplicable ? (
                         <div className="flex flex-col">
                           <span className="text-blue-700 bg-blue-100 px-2 py-0.5 rounded text-sm font-bold w-fit">Yes</span>
                           <span className="text-xs text-blue-600 mt-1">Est. VAT: ETB {result.vatAmount?.toFixed(2)}</span>
                         </div>
                        ) : (
                        <span className="text-slate-600 bg-slate-100 px-2 py-0.5 rounded text-sm font-bold">No</span>
                        )}
                    </div>
                </div>
            </div>
          </div>

          <div className="flex gap-3">
            <button 
              onClick={handleSave}
              className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 rounded-lg transition-colors"
            >
              Confirm & Add to Ledger
            </button>
            <button 
              onClick={() => {setPreview(null); setResult(null);}}
              className="px-6 py-3 border border-slate-200 text-slate-600 font-semibold rounded-lg hover:bg-slate-50 transition-colors"
            >
              Retake
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Scanner;
import React, { useState } from 'react';
import { User } from '../types';
import { Building2, Mail, Phone, MapPin, Save, ShieldCheck, Calendar, Settings, Globe } from 'lucide-react';

interface ProfileProps {
  user: User;
  onUpdateUser: (user: User) => void;
}

const Profile: React.FC<ProfileProps> = ({ user, onUpdateUser }) => {
  const [formData, setFormData] = useState<User>(user);
  const [isSaving, setIsSaving] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (message) setMessage(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 600));
      onUpdateUser(formData);
      setMessage({ type: 'success', text: 'Settings updated successfully.' });
    } catch (error) {
      setMessage({ type: 'error', text: 'Failed to update profile.' });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Settings & Profile</h2>
          <p className="text-slate-500 text-sm mt-1">Manage company details, tax modes, and preferences.</p>
        </div>
      </div>

      {message && (
        <div className={`p-4 rounded-lg border flex items-center gap-2 ${
          message.type === 'success' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-red-50 text-red-700 border-red-200'
        }`}>
          {message.type === 'success' ? <ShieldCheck size={20}/> : null}
          {message.text}
        </div>
      )}

      <form onSubmit={handleSubmit} className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="px-8 py-6 border-b border-slate-200 bg-slate-50/50 flex items-center gap-4">
             <div className="w-16 h-16 bg-indigo-600 rounded-full flex items-center justify-center text-white font-bold text-2xl shadow-lg shadow-indigo-200">
               {formData.businessName.charAt(0).toUpperCase()}
             </div>
             <div>
               <h3 className="text-xl font-bold text-slate-900">{formData.businessName}</h3>
               <p className="text-slate-500 text-sm">{formData.businessType} • {formData.tin}</p>
             </div>
        </div>

        <div className="p-8 grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Tax Configuration */}
          <div className="space-y-6">
            <h4 className="text-lg font-semibold text-slate-800 border-b pb-2 flex items-center gap-2">
              <Settings size={18} /> Tax Configuration
            </h4>
            
            <div className="space-y-4">
               <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">Tax Regime</label>
                <select
                  name="taxMode"
                  value={formData.taxMode || 'VAT'}
                  onChange={handleChange}
                  className="w-full px-4 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 bg-white"
                >
                  <option value="VAT">Value Added Tax (VAT 15%)</option>
                  <option value="TOT">Turnover Tax (TOT 2% or 10%)</option>
                </select>
                <p className="text-xs text-slate-500 mt-1">Determines how tax is calculated on invoices and reports.</p>
              </div>

              {formData.taxMode === 'TOT' && (
                <div>
                   <label className="block text-sm font-bold text-slate-700 mb-1">TOT Rate</label>
                   <select
                    name="totRate"
                    // @ts-ignore
                    value={formData.totRate || 2}
                    onChange={handleChange}
                    className="w-full px-4 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 bg-white"
                  >
                    <option value="2">2% (Goods / Contractors)</option>
                    <option value="10">10% (Services / Professionals)</option>
                  </select>
                </div>
              )}

              <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">Fiscal Year End</label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input
                    type="text"
                    name="fiscalYearEnd"
                    placeholder="e.g., Hamle 30"
                    value={formData.fiscalYearEnd || ''}
                    onChange={handleChange}
                    className="w-full pl-10 pr-4 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Contact Details */}
          <div className="space-y-6">
            <h4 className="text-lg font-semibold text-slate-800 border-b pb-2 flex items-center gap-2">
               <Building2 size={18} /> Business Details
            </h4>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">TIN Number</label>
                <input
                  type="text"
                  name="tin"
                  value={formData.tin}
                  onChange={handleChange}
                  className="w-full px-4 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">Phone Number</label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input
                    type="tel"
                    name="phoneNumber"
                    value={formData.phoneNumber || ''}
                    onChange={handleChange}
                    className="w-full pl-10 pr-4 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">Language</label>
                <div className="relative">
                  <Globe className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <select
                    name="language"
                    value={formData.language || 'en'}
                    onChange={handleChange}
                    className="w-full pl-10 pr-4 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 bg-white"
                  >
                    <option value="en">English</option>
                    <option value="am">Amharic (አማርኛ)</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="px-8 py-6 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            type="submit"
            disabled={isSaving}
            className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 px-8 rounded-lg transition-all shadow-md hover:shadow-lg disabled:opacity-70"
          >
            <Save size={20} />
            {isSaving ? 'Saving...' : 'Save Settings'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default Profile;

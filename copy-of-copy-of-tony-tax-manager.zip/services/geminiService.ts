import { GoogleGenAI, Type } from "@google/genai";
import { Transaction, TransactionType, User } from "../types";

// Helper to get AI instance safely
const getAI = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key not found");
  }
  return new GoogleGenAI({ apiKey });
};

interface ParsedReceipt {
  merchant: string;
  date: string;
  amount: number;
  category: string;
  description: string;
  isDeductible: boolean;
  isVATApplicable: boolean;
  withholdingAmount?: number;
}

// Chatbot Feature with Thinking Mode
export const askTony = async (query: string, contextData: string): Promise<string> => {
  const ai = getAI();
  
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview", // Using Pro for complex reasoning
      contents: `
        You are "Tony", an expert Ethiopian Tax Accountant and Auditor.
        Context Data: ${contextData}
        
        User Query: "${query}"
        
        Provide a helpful, accurate answer based on Ethiopian Tax Law (Proclamations).
        If the user asks about specific numbers, use the context provided.
        Keep it professional but conversational.
        If helpful, mention specific forms like "Form 005" or "Form 007" (Withholding).
      `,
      config: {
        thinkingConfig: { thinkingBudget: 32768 }, // Max thinking budget for deep reasoning
      }
    });
    return response.text || "I'm thinking, but couldn't come up with an answer.";
  } catch (error) {
    console.error("AskTony Error:", error);
    return "Sorry, I am having trouble connecting to the Ministry of Intelligence (AI Error).";
  }
};

export const analyzeReceiptImage = async (base64Image: string): Promise<ParsedReceipt> => {
  const ai = getAI();

  // Remove data URL prefix if present
  const base64Data = base64Image.replace(/^data:image\/(png|jpeg|jpg|webp);base64,/, "");

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: base64Data
            }
          },
          {
            text: "Analyze this receipt for an Ethiopian business. Extract merchant, date, total amount (ETB), category. Detect if VAT (15%) or TOT (2%/10%) was charged. IMPORTANT: Check if this is a transaction > 3000 ETB that might require 2% withholding tax."
          }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            merchant: { type: Type.STRING },
            date: { type: Type.STRING },
            amount: { type: Type.NUMBER },
            category: { type: Type.STRING },
            description: { type: Type.STRING },
            isDeductible: { type: Type.BOOLEAN },
            isVATApplicable: { type: Type.BOOLEAN },
            withholdingAmount: { type: Type.NUMBER }
          },
          required: ["merchant", "date", "amount", "category", "isDeductible", "isVATApplicable"]
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as ParsedReceipt;
    }
    throw new Error("No data returned from Gemini");
  } catch (error) {
    console.error("Gemini Receipt Analysis Error:", error);
    throw error;
  }
};

export const generateTaxInsights = async (transactions: Transaction[], user: User): Promise<string> => {
  const ai = getAI();

  // --- VAT Pre-calculation Logic ---
  let totalOutputVAT = 0;
  let totalInputVAT = 0;
  let vatableIncome = 0;
  let vatableExpenses = 0;

  // Filter last 100 transactions for detailed analysis list
  const simplifiedData = transactions.slice(0, 100).map(t => {
    // Use manual VAT amount if provided, otherwise calculate 15% of gross
    let vatComponent = 0;
    
    if (t.isVATApplicable) {
        if (t.vatAmount !== undefined && t.vatAmount !== null) {
            vatComponent = t.vatAmount;
        } else {
            // Default fallback: Amount * 0.15 / 1.15
            vatComponent = (t.amount * 0.15) / 1.15;
        }

        if (t.type === TransactionType.INCOME) {
            totalOutputVAT += vatComponent;
            vatableIncome += t.amount;
        } else {
            totalInputVAT += vatComponent;
            vatableExpenses += t.amount;
        }
    }

    return {
      date: t.date,
      type: t.type,
      category: t.category,
      amount: t.amount,
      deductible: t.isDeductible,
      vatApplicable: t.isVATApplicable,
      vatAmount: vatComponent.toFixed(2),
      withholding: t.withholdingTax
    };
  });

  const netVATPosition = totalOutputVAT - totalInputVAT;
  const vatStatus = netVATPosition > 0 ? "PAYABLE to Tax Authority" : "CREDIT (Refundable/Carry Forward)";

  const prompt = `
    You are "Tony", a Senior Professional Finance Auditor and Tax Consultant specializing in Ethiopian Tax Law.
    
    Conduct a rigorous financial audit for:
    - Business Name: ${user.businessName}
    - Tax Mode: ${user.taxMode}
    
    --- PRE-CALCULATED TAX SUMMARY ---
    - Total Vatable Income (Gross): ETB ${vatableIncome.toFixed(2)}
    - Output VAT (Collected): ETB ${totalOutputVAT.toFixed(2)}
    - Input VAT (Paid): ETB ${totalInputVAT.toFixed(2)}
    - **NET POSITION**: ETB ${Math.abs(netVATPosition).toFixed(2)} (${vatStatus})
    -----------------------------------------------------------------------

    Transaction Ledger Data: 
    ${JSON.stringify(simplifiedData)}

    Provide a formal Audit Report in Markdown.
    
    Structure:
    1. Executive Summary
    2. Tax Compliance (Focus on ${user.taxMode} & Withholding Tax checks)
    3. Expense Audit (Flag suspicious non-deductibles)
    4. Profit Tax Estimation (Use progressive rates if Sole Prop, 30% if PLC)
    5. Strategic Recommendations (Cash flow, penalties avoidance)
    
    Mention specific Ethiopian forms (Form 005 for VAT, Form 007 for Withholding).
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
    });

    return response.text || "Unable to generate report.";
  } catch (error) {
    console.error("Gemini Tax Report Error:", error);
    return "Error generating tax insights. Please try again later.";
  }
};

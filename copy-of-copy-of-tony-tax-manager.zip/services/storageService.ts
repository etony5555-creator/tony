import { User, Transaction, Invoice, Employee } from '../types';

const USERS_KEY = 'tonytax_users';
const TRANSACTIONS_KEY = 'tonytax_transactions';
const INVOICES_KEY = 'tonytax_invoices';
const EMPLOYEES_KEY = 'tonytax_employees';

const generateId = () => Math.random().toString(36).substr(2, 9);

// --- User Management ---

export const registerUser = (email: string, businessName: string, tin: string, businessType: string): User | null => {
  const usersStr = localStorage.getItem(USERS_KEY);
  const users: User[] = usersStr ? JSON.parse(usersStr) : [];

  if (users.find(u => u.email === email)) {
    return null;
  }

  const newUser: User = {
    id: generateId(),
    email,
    businessName,
    tin,
    businessType,
    createdAt: new Date().toISOString(),
    taxMode: 'VAT', // Default
    language: 'en'
  };

  users.push(newUser);
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
  return newUser;
};

export const loginUser = (email: string): User | null => {
  const usersStr = localStorage.getItem(USERS_KEY);
  const users: User[] = usersStr ? JSON.parse(usersStr) : [];
  return users.find(u => u.email === email) || null;
};

export const updateUserProfile = (updatedUser: User): User => {
  const usersStr = localStorage.getItem(USERS_KEY);
  let users: User[] = usersStr ? JSON.parse(usersStr) : [];
  const index = users.findIndex(u => u.id === updatedUser.id);
  
  if (index !== -1) {
    users[index] = updatedUser;
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
    return updatedUser;
  }
  return updatedUser;
};

// --- Transaction Management ---

export const getTransactions = (userId: string): Transaction[] => {
  const allTransStr = localStorage.getItem(TRANSACTIONS_KEY);
  const allTrans: Transaction[] = allTransStr ? JSON.parse(allTransStr) : [];
  return allTrans.filter(t => t.userId === userId).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
};

export const saveTransaction = (transaction: Omit<Transaction, 'id'>): Transaction => {
  const allTransStr = localStorage.getItem(TRANSACTIONS_KEY);
  const allTrans: Transaction[] = allTransStr ? JSON.parse(allTransStr) : [];

  const newTrans: Transaction = {
    ...transaction,
    id: generateId(),
    lastModifiedAt: new Date().toISOString(),
    lastModifiedBy: transaction.userId,
  };

  allTrans.push(newTrans);
  localStorage.setItem(TRANSACTIONS_KEY, JSON.stringify(allTrans));
  return newTrans;
};

export const deleteTransaction = (id: string) => {
  const allTransStr = localStorage.getItem(TRANSACTIONS_KEY);
  let allTrans: Transaction[] = allTransStr ? JSON.parse(allTransStr) : [];
  allTrans = allTrans.filter(t => t.id !== id);
  localStorage.setItem(TRANSACTIONS_KEY, JSON.stringify(allTrans));
};

export const updateTransaction = (updated: Transaction, editorId: string): Transaction => {
  const allTransStr = localStorage.getItem(TRANSACTIONS_KEY);
  let allTrans: Transaction[] = allTransStr ? JSON.parse(allTransStr) : [];
  const index = allTrans.findIndex(t => t.id === updated.id);
  if (index !== -1) {
    const modifiedTransaction = {
      ...updated,
      lastModifiedAt: new Date().toISOString(),
      lastModifiedBy: editorId
    };
    allTrans[index] = modifiedTransaction;
    localStorage.setItem(TRANSACTIONS_KEY, JSON.stringify(allTrans));
    return modifiedTransaction;
  }
  return updated;
};

// --- Invoice Management ---

export const getInvoices = (userId: string): Invoice[] => {
  const str = localStorage.getItem(INVOICES_KEY);
  const items: Invoice[] = str ? JSON.parse(str) : [];
  return items.filter(i => i.userId === userId).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
};

export const saveInvoice = (invoice: Omit<Invoice, 'id'>): Invoice => {
  const str = localStorage.getItem(INVOICES_KEY);
  const items: Invoice[] = str ? JSON.parse(str) : [];
  const newItem = { ...invoice, id: generateId() };
  items.push(newItem);
  localStorage.setItem(INVOICES_KEY, JSON.stringify(items));
  return newItem;
};

// --- Payroll Management ---

export const getEmployees = (userId: string): Employee[] => {
  const str = localStorage.getItem(EMPLOYEES_KEY);
  const items: Employee[] = str ? JSON.parse(str) : [];
  return items.filter(i => i.userId === userId);
};

export const saveEmployee = (emp: Omit<Employee, 'id'>): Employee => {
  const str = localStorage.getItem(EMPLOYEES_KEY);
  const items: Employee[] = str ? JSON.parse(str) : [];
  const newItem = { ...emp, id: generateId() };
  items.push(newItem);
  localStorage.setItem(EMPLOYEES_KEY, JSON.stringify(items));
  return newItem;
};

export const deleteEmployee = (id: string) => {
  const str = localStorage.getItem(EMPLOYEES_KEY);
  let items: Employee[] = str ? JSON.parse(str) : [];
  items = items.filter(i => i.id !== id);
  localStorage.setItem(EMPLOYEES_KEY, JSON.stringify(items));
};
